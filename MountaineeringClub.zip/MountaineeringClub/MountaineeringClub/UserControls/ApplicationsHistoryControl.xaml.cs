﻿using MountaineeringClub.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MountaineeringClub.UserControls
{
    /// <summary>
    /// Логика взаимодействия для ApplicationsHistoryControl.xaml
    /// </summary>
    public partial class ApplicationsHistoryControl : UserControl
    {
        private int current_participant;

        public ApplicationsHistoryControl(int participantID)
        {
            InitializeComponent();
            current_participant = participantID;
            LoadApplications();
        }
        private void LoadApplications()
        {
            ApplicationsControl.Items.Clear();

            using (var db = new DbMountaineeringClubContext())
            {

                var applications = db.Applications.Include(a => a.Participant)
                                            .Include(a => a.Ascent).ThenInclude(app => app.Mountain)
                                            .Where(a => a.ParticipantId == current_participant &&
                                                    (a.Ascent == null || a.Ascent.AscentStatus != "выполнено")).ToList();

                foreach (var application in applications)
                {
                    ApplicationsControl.Items.Add(application);
                }
            }
        }
    }
}
