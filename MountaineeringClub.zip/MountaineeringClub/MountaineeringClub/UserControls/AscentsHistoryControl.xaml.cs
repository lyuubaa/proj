﻿using Microsoft.EntityFrameworkCore;
using MountaineeringClub.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MountaineeringClub.UserControls
{
    /// <summary>
    /// Логика взаимодействия для AscentsHistoryControl.xaml
    /// </summary>
    public partial class AscentsHistoryControl : UserControl
    {
        private int current_participant;
        public AscentsHistoryControl(int participantID)
        {
            InitializeComponent();
            current_participant = participantID;
            LoadAscents();
        }
        private void LoadAscents()
        {
            AscentsControl.Items.Clear();



            using (var db = new DbMountaineeringClubContext())
            {

                var completedAscents = db.Applications
                                                 .Include(a => a.Participant)
                                                 .Include(a => a.Ascent).ThenInclude(app => app.Mountain)
                                                 .Where(a => a.ApplicationStatus == "выполнено" &&
                                                        a.ParticipantId == current_participant).ToList();
                foreach (var ascent in completedAscents)
                {
                    AscentsControl.Items.Add(ascent);
                }
                


                    

            }
        }
    }
}
