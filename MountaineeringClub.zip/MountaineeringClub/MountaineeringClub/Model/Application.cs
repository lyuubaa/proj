﻿using System;
using System.Collections.Generic;

namespace MountaineeringClub.Model;

public partial class Application
{
    public int ApplicationId { get; set; }

    public int ParticipantId { get; set; }

    public DateOnly ApplicationDate { get; set; }

    public string DesiredRole { get; set; } = null!;

    public string ApplicationStatus { get; set; } = null!;

    public int AscentId { get; set; }

    public virtual Ascent Ascent { get; set; } = null!;

    public virtual Participant Participant { get; set; } = null!;
}
