﻿using System;
using System.Collections.Generic;

namespace MountaineeringClub.Model;

public partial class Participant
{
    public int ParticipantId { get; set; }

    public int UserId { get; set; }

    public string MembershipStatus { get; set; } = null!;

    public string? AscentHistory { get; set; }

    public virtual ICollection<Application> Applications { get; set; } = new List<Application>();

    public virtual User User { get; set; } = null!;
}
