﻿using System;
using System.Collections.Generic;

namespace MountaineeringClub.Model;

public partial class Photograph
{
    public int PhotographId { get; set; }

    public int AscentId { get; set; }

    public byte[]? Image { get; set; }

    public string? Description { get; set; }

    public virtual Ascent Ascent { get; set; } = null!;
}
