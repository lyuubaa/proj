﻿using System;
using System.Collections.Generic;

namespace MountaineeringClub.Model;

public partial class User
{
    public int UserId { get; set; }

    public string Name { get; set; } = null!;

    public string Surname { get; set; } = null!;

    public string Patronymic { get; set; } = null!;

    public string ContactPhone { get; set; } = null!;

    public string? EmailAddress { get; set; }

    public string Password { get; set; } = null!;

    public DateOnly? BirthDate { get; set; }

    public DateOnly? RegistrationDate { get; set; }

    public string Role { get; set; } = null!;
    public string FullName => $"{Surname} {Name} {Patronymic}";

    public virtual ICollection<Participant> Participants { get; set; } = new List<Participant>();
}
