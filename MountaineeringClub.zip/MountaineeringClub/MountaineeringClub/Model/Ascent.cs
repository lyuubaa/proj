﻿using System;
using System.Collections.Generic;

namespace MountaineeringClub.Model;

public partial class Ascent
{
    public int AscentId { get; set; }

    public DateOnly? StartDate { get; set; }

    public DateOnly? EndDate { get; set; }

    public string? RouteDescription { get; set; }

    public string AscentStatus { get; set; } = null!;

    public int MountainId { get; set; }

    public string TargetPoint { get; set; } = null!;

    public virtual ICollection<Application> Applications { get; set; } = new List<Application>();

    public virtual Mountain Mountain { get; set; } = null!;

    public virtual ICollection<Photograph> Photographs { get; set; } = new List<Photograph>();
    public string DateRange => $"{StartDate:dd.MM.yyyy} - {EndDate:dd.MM.yyyy}";
}
