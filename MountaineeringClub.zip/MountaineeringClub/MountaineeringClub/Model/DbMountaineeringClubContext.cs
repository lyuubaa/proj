﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Pomelo.EntityFrameworkCore.MySql.Scaffolding.Internal;

namespace MountaineeringClub.Model;

public partial class DbMountaineeringClubContext : DbContext
{
    public DbMountaineeringClubContext()
    {
    }

    public DbMountaineeringClubContext(DbContextOptions<DbMountaineeringClubContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Application> Applications { get; set; }

    public virtual DbSet<Ascent> Ascents { get; set; }

    public virtual DbSet<Mountain> Mountains { get; set; }

    public virtual DbSet<Participant> Participants { get; set; }

    public virtual DbSet<Photograph> Photographs { get; set; }

    public virtual DbSet<User> Users { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseMySql("server=localhost;user=root;password=1234;database=db_mountaineering_club", Microsoft.EntityFrameworkCore.ServerVersion.Parse("8.0.41-mysql"));

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder
            .UseCollation("utf8mb4_0900_ai_ci")
            .HasCharSet("utf8mb4");

        modelBuilder.Entity<Application>(entity =>
        {
            entity.HasKey(e => e.ApplicationId).HasName("PRIMARY");

            entity.ToTable("application");

            entity.HasIndex(e => e.AscentId, "ascent_id_fk_idx");

            entity.HasIndex(e => e.ParticipantId, "participant_id_fk_idx");

            entity.Property(e => e.ApplicationId).HasColumnName("application_id");
            entity.Property(e => e.ApplicationDate).HasColumnName("application_date");
            entity.Property(e => e.ApplicationStatus)
                .HasColumnType("enum('на рассмотрении','одобрено','отклонено','выполнено')")
                .HasColumnName("application_status");
            entity.Property(e => e.AscentId).HasColumnName("ascent_id");
            entity.Property(e => e.DesiredRole)
                .HasColumnType("enum('участник','руководитель')")
                .HasColumnName("desired_role");
            entity.Property(e => e.ParticipantId).HasColumnName("participant_id");

            entity.HasOne(d => d.Ascent).WithMany(p => p.Applications)
                .HasForeignKey(d => d.AscentId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("ascent_id_fk");

            entity.HasOne(d => d.Participant).WithMany(p => p.Applications)
                .HasForeignKey(d => d.ParticipantId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("participant_id_fk");
        });

        modelBuilder.Entity<Ascent>(entity =>
        {
            entity.HasKey(e => e.AscentId).HasName("PRIMARY");

            entity.ToTable("ascent");

            entity.HasIndex(e => e.MountainId, "ascent_ibfk_1");

            entity.Property(e => e.AscentId).HasColumnName("ascent_id");
            entity.Property(e => e.AscentStatus)
                .HasColumnType("enum('запланировано','не удалось','отменено','выполнено')")
                .HasColumnName("ascent_status");
            entity.Property(e => e.EndDate).HasColumnName("end_date");
            entity.Property(e => e.MountainId).HasColumnName("mountain_id");
            entity.Property(e => e.RouteDescription)
                .HasColumnType("text")
                .HasColumnName("route_description");
            entity.Property(e => e.StartDate).HasColumnName("start_date");
            entity.Property(e => e.TargetPoint)
                .HasMaxLength(255)
                .HasColumnName("target_point");

            entity.HasOne(d => d.Mountain).WithMany(p => p.Ascents)
                .HasForeignKey(d => d.MountainId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("ascent_ibfk_1");
        });

        modelBuilder.Entity<Mountain>(entity =>
        {
            entity.HasKey(e => e.MountainId).HasName("PRIMARY");

            entity.ToTable("mountain");

            entity.Property(e => e.MountainId).HasColumnName("mountain_id");
            entity.Property(e => e.Country)
                .HasMaxLength(255)
                .HasColumnName("country");
            entity.Property(e => e.Description)
                .HasColumnType("text")
                .HasColumnName("description");
            entity.Property(e => e.Height)
                .HasPrecision(10, 2)
                .HasColumnName("height");
            entity.Property(e => e.Name)
                .HasMaxLength(255)
                .HasColumnName("name");
            entity.Property(e => e.Region)
                .HasMaxLength(255)
                .HasColumnName("region");
        });

        modelBuilder.Entity<Participant>(entity =>
        {
            entity.HasKey(e => e.ParticipantId).HasName("PRIMARY");

            entity.ToTable("participant");

            entity.HasIndex(e => e.UserId, "user_id_fk_idx");

            entity.Property(e => e.ParticipantId).HasColumnName("participant_id");
            entity.Property(e => e.AscentHistory)
                .HasColumnType("text")
                .HasColumnName("ascent_history");
            entity.Property(e => e.MembershipStatus)
                .HasColumnType("enum('активный','неактивный')")
                .HasColumnName("membership_status");
            entity.Property(e => e.UserId).HasColumnName("user_id");

            entity.HasOne(d => d.User).WithMany(p => p.Participants)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("user_id_fk");
        });

        modelBuilder.Entity<Photograph>(entity =>
        {
            entity.HasKey(e => e.PhotographId).HasName("PRIMARY");

            entity.ToTable("photograph");

            entity.HasIndex(e => e.AscentId, "photograph_ibfk_1");

            entity.Property(e => e.PhotographId).HasColumnName("photograph_id");
            entity.Property(e => e.AscentId).HasColumnName("ascent_id");
            entity.Property(e => e.Description)
                .HasColumnType("text")
                .HasColumnName("description");
            entity.Property(e => e.Image)
                .HasColumnType("blob")
                .HasColumnName("image");

            entity.HasOne(d => d.Ascent).WithMany(p => p.Photographs)
                .HasForeignKey(d => d.AscentId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("photograph_ibfk_1");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.UserId).HasName("PRIMARY");

            entity.ToTable("user");

            entity.HasIndex(e => e.ContactPhone, "contact_phone_UNIQUE").IsUnique();

            entity.HasIndex(e => e.EmailAddress, "email_address_UNIQUE").IsUnique();

            entity.Property(e => e.UserId).HasColumnName("user_id");
            entity.Property(e => e.BirthDate).HasColumnName("birth_date");
            entity.Property(e => e.ContactPhone)
                .HasMaxLength(20)
                .HasColumnName("contact_phone");
            entity.Property(e => e.EmailAddress).HasColumnName("email_address");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .HasColumnName("name");
            entity.Property(e => e.Password)
                .HasMaxLength(255)
                .HasColumnName("password");
            entity.Property(e => e.Patronymic)
                .HasMaxLength(100)
                .HasColumnName("patronymic");
            entity.Property(e => e.RegistrationDate).HasColumnName("registration_date");
            entity.Property(e => e.Role)
                .HasColumnType("enum('администратор','зарегистрированный участник')")
                .HasColumnName("role");
            entity.Property(e => e.Surname)
                .HasMaxLength(100)
                .HasColumnName("surname");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
