﻿using System;
using System.Collections.Generic;

namespace MountaineeringClub.Model;

public partial class Mountain
{
    public int MountainId { get; set; }

    public string Name { get; set; } = null!;

    public decimal? Height { get; set; }

    public string? Country { get; set; }

    public string? Region { get; set; }

    public string? Description { get; set; }

    public virtual ICollection<Ascent> Ascents { get; set; } = new List<Ascent>();
}
