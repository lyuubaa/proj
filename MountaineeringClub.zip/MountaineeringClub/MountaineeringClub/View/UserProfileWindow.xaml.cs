﻿using Microsoft.EntityFrameworkCore;
using MountaineeringClub.Model;
using MountaineeringClub.UserControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MountaineeringClub.View
{
    /// <summary>
    /// Логика взаимодействия для UserProfileWindow.xaml
    /// </summary>
    public partial class UserProfileWindow : Window
    {
        private Model.User current_user;
        private Participant current_participant;
        public UserProfileWindow(User user)
        {
            InitializeComponent();
            current_user = user;
            DataContext = current_user;
            LoadDatas();
        }

        private void LoadDatas()
        {
            using (var db = new DbMountaineeringClubContext())
            {
                current_participant = db.Participants
                    .Where(p => p.UserId == current_user.UserId).FirstOrDefault();

                if (ApplicationsListView != null)
                    ApplicationsListView.Items.Clear();

                ApplicationsListView.Items.Add(new ApplicationsHistoryControl(current_participant.ParticipantId));


                if (AscentsHistoryList != null)
                    AscentsHistoryList.Items.Clear();


                AscentsHistoryList.Items.Add(new AscentsHistoryControl(current_participant.ParticipantId));

                int activeApplications = GetActiveApplicationsCount(current_participant.ParticipantId);
                int activeAscents = GetActiveAscentsCount(current_participant.ParticipantId);

                noApplications_msg.Visibility = activeApplications == 0
                    ? Visibility.Visible
                    : Visibility.Collapsed;

                noAscents_msg.Visibility = activeAscents == 0
                    ? Visibility.Visible
                    : Visibility.Collapsed;
            }

        }

        private int GetActiveApplicationsCount(int participantId)
        {
            using (var db = new DbMountaineeringClubContext())
            {
                return db.Applications
                    .Where(a => a.ParticipantId == participantId &&
                               (a.Ascent == null || a.Ascent.AscentStatus != "выполнено"))
                    .Count();
            }
        }

        private int GetActiveAscentsCount(int participantId)
        {
            using (var db = new DbMountaineeringClubContext())
            {
                return db.Applications
                                    .Include(a => a.Participant)
                                    .Where(a => a.ApplicationStatus == "выполнено" &&
                                        a.ParticipantId == participantId).Count();
            }
        }
        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            new MounCMain().Show();
            this.Close();
        }

        private void NewApplicationButton_Click(object sender, RoutedEventArgs e)
        {
            var newAppWindow = new NewApplicationWindow(current_user);
            newAppWindow.Owner = this;
            if (newAppWindow.ShowDialog() == true)
            {
                LoadDatas();
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            SwitchToViewMode();
        }
        private void EditProfileButton_Click(object sender, RoutedEventArgs e)
        {
            NewApplicationButton.IsEnabled = false;
            UserNameText.Visibility = Visibility.Collapsed;
            UserSPText.Visibility = Visibility.Collapsed;
            UserEmailText.Visibility = Visibility.Collapsed;
            UserPhoneText.Visibility = Visibility.Collapsed;
            UserRegDateText.Visibility = Visibility.Collapsed;
            LeaveTheClubButton.Visibility = Visibility.Collapsed;

            EditFieldsPanel.Visibility = Visibility.Visible;
            EditProfileButton.Visibility = Visibility.Collapsed;
            EditButtonsPanel.Visibility = Visibility.Visible;

            SurnameTextBox.Text = current_user.Surname;
            NameTextBox.Text = current_user.Name;
            PatronymicTextBox.Text = current_user.Patronymic;
            EmailTextBox.Text = current_user.EmailAddress;
            PhoneTextBox.Text = current_user.ContactPhone;
        }

   

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(SurnameTextBox.Text))
            {
                MessageBox.Show("Пожалуйста, укажите фамилию", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                SurnameTextBox.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(NameTextBox.Text))
            {
                MessageBox.Show("Пожалуйста, укажите имя", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                NameTextBox.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(PatronymicTextBox.Text))
            {
                MessageBox.Show("Пожалуйста, укажите отчество", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                SurnameTextBox.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(EmailTextBox.Text))
            {
                MessageBox.Show("Пожалуйста, укажите email", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                EmailTextBox.Focus();
                return;
            }
            else if (!EmailTextBox.Text.Contains("@") || !EmailTextBox.Text.Contains("."))
            {
                MessageBox.Show("Пожалуйста, укажите корректный email", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                EmailTextBox.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(PhoneTextBox.Text))
            {
                MessageBox.Show("Пожалуйста, укажите телефон", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                PhoneTextBox.Focus();
                return;
            }
            else if (PhoneTextBox.Text.Length < 10)
            {
                MessageBox.Show("Номер телефона должен содержать не менее 10 цифр", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                PhoneTextBox.Focus();
                return;
            }

            try
            {
                using (var db = new DbMountaineeringClubContext())
                {
                    var userInDb = db.Users.Find(current_user.UserId);

                    userInDb.Surname = SurnameTextBox.Text.Trim();
                    userInDb.Name = NameTextBox.Text.Trim();
                    userInDb.Patronymic = PatronymicTextBox.Text.Trim();
                    userInDb.EmailAddress = EmailTextBox.Text.Trim();
                    userInDb.ContactPhone = PhoneTextBox.Text.Trim();

                    db.SaveChanges();

                    current_user = userInDb;

                    DataContext = null;
                    DataContext = current_user;
                }

                MessageBox.Show("Данные успешно сохранены!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                SwitchToViewMode();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SwitchToViewMode()
        {
            EditFieldsPanel.Visibility = Visibility.Collapsed;
            EditButtonsPanel.Visibility = Visibility.Collapsed;

            NewApplicationButton.IsEnabled = true;

            UserNameText.Visibility = Visibility.Visible;
            UserSPText.Visibility = Visibility.Visible;
            UserEmailText.Visibility = Visibility.Visible;
            UserPhoneText.Visibility = Visibility.Visible;
            UserRegDateText.Visibility = Visibility.Visible;
            EditProfileButton.Visibility = Visibility.Visible;
            LeaveTheClubButton.Visibility = Visibility.Visible;
            
        }

        private void LeaveTheClubButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Вы точно хотите покинуть клуб?",
                                       "Подтверждение выхода",
                                       MessageBoxButton.YesNo,
                                       MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    using (var db = new DbMountaineeringClubContext())
                    {
                        var participant = db.Participants.FirstOrDefault(p => p.UserId == current_user.UserId);

                        if (participant != null)
                        {
                            participant.MembershipStatus = "неактивный";
                            db.SaveChanges();

                            new MounCMain().Show();
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Ошибка: участник не найден",
                                          "Ошибка",
                                          MessageBoxButton.OK,
                                          MessageBoxImage.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при выходе из клуба: {ex.Message}",
                                  "Ошибка",
                                  MessageBoxButton.OK,
                                  MessageBoxImage.Error);
                }
            }
        }
    }
}
