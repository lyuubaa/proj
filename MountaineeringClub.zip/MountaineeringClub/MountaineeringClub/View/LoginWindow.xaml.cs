﻿using MountaineeringClub.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MountaineeringClub.View
{
    /// <summary>
    /// Логика взаимодействия для LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            new RegisterWindow().Show();
            this.Close();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {

            if (string.IsNullOrWhiteSpace(LoginTextBox.Text) || PasswordBox.Password == null)
            {
                MessageBox.Show("Пожалуйста, введите логин и пароль", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            using (var db = new DbMountaineeringClubContext())
            {
                var userInDb = db.Users
               .FirstOrDefault(u => u.EmailAddress == LoginTextBox.Text || u.ContactPhone == LoginTextBox.Text);


                if (userInDb == null || userInDb.Password != PasswordBox.Password)
                {
                    MessageBox.Show("Неверный логин или пароль", "Ошибка входа", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                
                if (userInDb.Role == "администратор")
                {
                    new AdminWindow().Show();
                    this.Close();
                    return;

                }
                var participant = db.Participants.Where(p => p.UserId == userInDb.UserId).FirstOrDefault();

                if (participant.MembershipStatus == "активный")
                {
                    new UserProfileWindow(userInDb).Show();
                    this.Close();
                }                    
                else
                {
                    MessageBox.Show("Участник временно не состоит в клубе", "Ошибка входа", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
              

            }            
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            new MounCMain().Show();
            Close();
        }
    }
}
