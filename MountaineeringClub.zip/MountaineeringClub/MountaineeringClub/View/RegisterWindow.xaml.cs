﻿using System;
using System.Text.RegularExpressions;
using System.Windows;
using MountaineeringClub.Model;
using System.Linq;
using System.Windows.Controls;
using System.Windows.Media;

namespace MountaineeringClub.View
{
    public partial class RegisterWindow : Window
    {
        private DbMountaineeringClubContext db;

        public RegisterWindow()
        {
            InitializeComponent();
            db = new DbMountaineeringClubContext();
            BirthDatePicker.DisplayDateEnd = DateTime.Today.AddYears(-14);
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            new LoginWindow().Show();
            this.Close();
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {

            ResetErrorMessages();


            if (!ValidateFields())
                return;

                if (db.Users.Any(u => u.EmailAddress == EmailTextBox.Text))
                {
                    ShowError(EmailErrorText, "Этот email уже зарегистрирован");
                    return;
                }
                if (db.Users.Any(u => u.ContactPhone == PhoneTextBox.Text))
                {
                    ShowError(PhoneTextBox, "Этот номер телефона уже используется");
                    return;
                }
                

                DateTime? selectedDate = BirthDatePicker.SelectedDate;

                if (!selectedDate.HasValue)
                {
                    MessageBox.Show("Пожалуйста, выберите дату рождения", "Ошибка",
                                  MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                var newUser = new User
                {
                    Surname = LastNameTextBox.Text.Trim(),
                    Name = FirstNameTextBox.Text.Trim(),
                    Patronymic = MiddleNameTextBox.Text.Trim(),
                    BirthDate = DateOnly.FromDateTime(selectedDate.Value),
                    EmailAddress = EmailTextBox.Text.Trim(),
                    ContactPhone = PhoneTextBox.Text.Trim(),
                    RegistrationDate = DateOnly.FromDateTime(DateTime.Now),
                    Role = "зарегистрированный участник",
                    Password = PasswordBox.Password
                };


                db.Users.Add(newUser);
                db.SaveChanges();

                var newParticipant = new Participant
                {
                    UserId = newUser.UserId,
                    MembershipStatus = "активный",
                    AscentHistory = "" 
                };

                db.Participants.Add(newParticipant);
                db.SaveChanges();

                MessageBox.Show("Регистрация успешно завершена!", "Успех",
                              MessageBoxButton.OK, MessageBoxImage.Information);

                new LoginWindow().Show();
                this.Close();
          
        }

        private bool ValidateFields()
        {
            bool isValid = true;

            if (string.IsNullOrWhiteSpace(LastNameTextBox.Text))
            {
                ShowError(LastNameTextBox, "Введите фамилию");
                isValid = false;
            }

            if (string.IsNullOrWhiteSpace(FirstNameTextBox.Text))
            {
                ShowError(FirstNameTextBox, "Введите имя");
                isValid = false;
            }

            if (string.IsNullOrWhiteSpace(MiddleNameTextBox.Text))
            {
                ShowError(MiddleNameTextBox, "Введите отчество");
                isValid = false;
            }

            if (BirthDatePicker.SelectedDate == null)
            {
                MessageBox.Show("Укажите дату рождения", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                isValid = false;
            }
            else if (BirthDatePicker.SelectedDate > DateTime.Today.AddYears(-14))
            {
                MessageBox.Show("Минимальный возраст для регистрации - 14 лет", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                isValid = false;
            }

            if (string.IsNullOrWhiteSpace(EmailTextBox.Text))
            {
                ShowError(EmailTextBox, "Введите email");
                isValid = false;
            }
            else if (!IsValidEmail(EmailTextBox.Text))
            {
                ShowError(EmailErrorText, "Некорректный формат email");
                isValid = false;
            }

            if (string.IsNullOrEmpty(PasswordBox.Password))
            {
                ShowError(PasswordErrorText, "Введите пароль");
                isValid = false;
            }
            else if (PasswordBox.Password.Length < 6)
            {
                ShowError(PasswordErrorText, "Пароль должен содержать минимум 6 символов");
                isValid = false;
            }

            if (PasswordBox.Password != ConfirmPasswordBox.Password)
            {
                ShowError(PasswordErrorText, "Пароли не совпадают");
                isValid = false;
            }

            if (string.IsNullOrWhiteSpace(PhoneTextBox.Text))
            {
                ShowError(PhoneTextBox, "Введите номер телефона");
                isValid = false;
            }
            else if (!IsValidPhone(PhoneTextBox.Text))
            {
                ShowError(PhoneTextBox, "Некорректный формат телефона");
                isValid = false;
            }

            return isValid;
        }

        private void ResetErrorMessages()
        {
            EmailErrorText.Visibility = Visibility.Collapsed;
            PasswordErrorText.Visibility = Visibility.Collapsed;

            LastNameTextBox.ClearValue(TextBox.BorderBrushProperty);
            FirstNameTextBox.ClearValue(TextBox.BorderBrushProperty);
            MiddleNameTextBox.ClearValue(TextBox.BorderBrushProperty);
            EmailTextBox.ClearValue(TextBox.BorderBrushProperty);
            PhoneTextBox.ClearValue(TextBox.BorderBrushProperty);
        }

        private void ShowError(TextBlock errorTextBlock, string message)
        {
            errorTextBlock.Text = message;
            errorTextBlock.Visibility = Visibility.Visible;
        }

        private void ShowError(TextBox textBox, string message)
        {
            textBox.BorderBrush = Brushes.Red;
            textBox.ToolTip = message;
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        private bool IsValidPhone(string phone)
        {
            return Regex.IsMatch(phone, @"^[\d\s\(\)\-+]{10,}$");
        }
    }
}