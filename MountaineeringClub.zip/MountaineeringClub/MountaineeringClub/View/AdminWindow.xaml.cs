﻿using Microsoft.EntityFrameworkCore;
using MountaineeringClub.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using iText.Kernel.Pdf;
using iText.Layout;
using Microsoft.Win32;
using iText.Layout.Element;
using iText.Layout.Properties;
using iText.Kernel.Colors;
using System.IO;
using iText.Kernel.Geom;
using System.Data;
using iText.IO.Font;
using iText.Kernel.Font;

namespace MountaineeringClub.View
{
    /// <summary>
    /// Логика взаимодействия для AdminWindow.xaml
    /// </summary>
    public partial class AdminWindow : Window
    {
        private readonly DbMountaineeringClubContext db;

        public AdminWindow()
        {
            InitializeComponent();
            db = new DbMountaineeringClubContext();
            LoadData();

            ApplicationsGrid.BeginningEdit += ApplicationsGrid_BeginningEdit;
            AscentsGrid.BeginningEdit += AscentsGrid_BeginningEdit;
            ReportTypeComboBox.SelectedIndex = 0;
        }

        private void LoadData()
        {
            db.Applications
                .Include(a => a.Participant)
                .Include(a => a.Participant.User)
                .Include(a => a.Ascent)
                .Include(a => a.Ascent.Mountain)
                .Load();

            ApplicationsGrid.ItemsSource = db.Applications.Local.ToObservableCollection();

            db.Ascents
                .Include(a => a.Mountain)
                .Load();

            AscentsGrid.ItemsSource = db.Ascents.Local.ToObservableCollection();
        }

        private void ApplicationsGrid_BeginningEdit(object sender, DataGridBeginningEditEventArgs e)
        {
            if (e.Column.Header.ToString() != "Статус")
            {
                e.Cancel = true;
                return;
            }

            var application = e.Row.Item as Model.Application;
            if (application != null && application.ApplicationStatus == "выполнено")
            {
                e.Cancel = true;
                MessageBox.Show("Нельзя изменить статус 'выполнено'", "Ошибка",
                               MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void AscentsGrid_BeginningEdit(object sender, DataGridBeginningEditEventArgs e)
        {
            if (e.Column.Header.ToString() != "Статус")
            {
                e.Cancel = true;
                return;
            }

            var ascent = e.Row.Item as Ascent;
            if (ascent != null && ascent.AscentStatus == "выполнено")
            {
                e.Cancel = true;
                MessageBox.Show("Нельзя изменить статус 'выполнено'", "Ошибка",
                               MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void SaveChanges_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var changedEntries = db.ChangeTracker.Entries()
                    .Where(entry => entry.State == EntityState.Modified)
                    .ToList();

                bool hasCompletedChanges = changedEntries.Any(entry =>
                {
                    if (entry.Entity is Model.Application app)
                        return entry.OriginalValues["ApplicationStatus"].ToString() == "выполнено";
                    else if (entry.Entity is Ascent ascent)
                        return entry.OriginalValues["AscentStatus"].ToString() == "выполнено";
                    return false;
                });

                if (hasCompletedChanges)
                {
                    MessageBox.Show("Нельзя изменять записи со статусом 'выполнено'", "Ошибка",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (changedEntries.Any())
                {
                    db.SaveChanges();
                    MessageBox.Show("Изменения сохранены", "Успех",
                                  MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void GenerateMountainStatistics()
        {
            var mountainStats = db.Ascents
                .Include(a => a.Mountain)
                .GroupBy(a => a.Mountain.Name)
                .Select(g => new
                {
                    Гора = g.Key,
                    КоличествоВосхождений = g.Count(),
                    ПервоеВосхождение = g.Min(a => a.StartDate),
                    ПоследнееВосхождение = g.Max(a => a.StartDate)
                })
                .OrderByDescending(x => x.КоличествоВосхождений)
                .ThenBy(x => x.Гора)
                .ToList();

            DataTable table = new DataTable();
            table.Columns.Add("Гора", typeof(string));
            table.Columns.Add("Количество восхождений", typeof(int));
            table.Columns.Add("Первое восхождение", typeof(string));
            table.Columns.Add("Последнее восхождение", typeof(string));

            foreach (var stat in mountainStats)
            {
                table.Rows.Add(
                    stat.Гора,
                    stat.КоличествоВосхождений,
                    stat.ПервоеВосхождение?.ToString("dd.MM.yyyy") ?? "н/д",
                    stat.ПоследнееВосхождение?.ToString("dd.MM.yyyy") ?? "н/д"
                );
            }

            ReportsGrid.ItemsSource = table.DefaultView;

        }


        private void GenerateReport_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var selectedReport = (ReportTypeComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();

                switch (selectedReport)
                {
                    case "Статистика по горам (по количеству восхождений)":
                        GenerateMountainStatistics();
                        break;
                    case "Рейтинг участников (по количеству восхождений)":
                        GenerateParticipantRatings();
                        break;
                    case "Отчет по завершенным восхождениям (по дате)":
                        GenerateCompletedAscentsReport();
                        break;
                    default:
                        MessageBox.Show("Выберите тип отчета", "Ошибка",
                                      MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при формировании отчета: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void GenerateParticipantRatings()
        {
            var participantRatings = db.Applications
                .Where(a => a.ApplicationStatus == "выполнено")
                .Select(a => new
                {
                    UserId = a.Participant.User.UserId,
                    Surname = a.Participant.User.Surname,
                    Name = a.Participant.User.Name,
                    Patronymic = a.Participant.User.Patronymic,
                    StartDate = a.Ascent.StartDate
                })
                .AsEnumerable()
                .GroupBy(a => new
                {
                    a.UserId,
                    FullName = $"{a.Surname} {a.Name} {a.Patronymic}"
                })
                .Select(g => new
                {
                    Участник = g.Key.FullName,
                    КоличествоВосхождений = g.Count(),
                    ПервоеВосхождение = g.Min(a => a.StartDate),
                    ПоследнееВосхождение = g.Max(a => a.StartDate)
                })
                .OrderByDescending(x => x.КоличествоВосхождений)
                .ToList();

            DataTable table = new DataTable();
            table.Columns.Add("Участник", typeof(string));
            table.Columns.Add("Количество восхождений", typeof(int));
            table.Columns.Add("Первое восхождение", typeof(string));
            table.Columns.Add("Последнее восхождение", typeof(string));

            foreach (var rating in participantRatings)
            {
                table.Rows.Add(
                    rating.Участник,
                    rating.КоличествоВосхождений,
                    rating.ПервоеВосхождение?.ToString("dd.MM.yyyy") ?? "н/д",
                    rating.ПоследнееВосхождение?.ToString("dd.MM.yyyy") ?? "н/д"
                );
            }

            ReportsGrid.ItemsSource = table.DefaultView;
        }

        private void GenerateCompletedAscentsReport()
        {
            var completedAscents = db.Ascents
                .Include(a => a.Mountain)
                .Where(a => a.AscentStatus == "выполнено")
                .OrderByDescending(a => a.StartDate)
                .Select(a => new
                {
                    Гора = a.Mountain.Name,
                    Высота = a.Mountain.Height,
                    Дата = a.StartDate,
                    Цель = a.TargetPoint,
                    Продолжительность = a.StartDate.HasValue && a.EndDate.HasValue
                                        ? (a.EndDate.Value.DayNumber - a.StartDate.Value.DayNumber + 1)
                                        : (int?)null
                })
                .ToList();

            DataTable table = new DataTable();
            table.Columns.Add("Гора", typeof(string));
            table.Columns.Add("Высота", typeof(decimal));
            table.Columns.Add("Дата", typeof(string));
            table.Columns.Add("Цель", typeof(string));
            table.Columns.Add("Продолжительность", typeof(string));

            foreach (var ascent in completedAscents)
            {
                table.Rows.Add(
                    ascent.Гора,
                    ascent.Высота,
                    ascent.Дата?.ToString("dd.MM.yyyy") ?? "н/д",
                    ascent.Цель,
                    ascent.Продолжительность?.ToString() ?? "н/д"
                );
            }

            ReportsGrid.ItemsSource = table.DefaultView;
        }

        private void ExportToPDF_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ReportsGrid.Items.Count == 0)
                {
                    MessageBox.Show("Нет данных для экспорта", "Ошибка",
                                 MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                string fontPath = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Fonts), "arial.ttf");
                if (!File.Exists(fontPath))
                {
                    fontPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Fonts", "times.ttf");
                }

                var saveFileDialog = new SaveFileDialog
                {
                    Filter = "PDF files (*.pdf)|*.pdf",
                    FileName = $"Отчет_{DateTime.Now:yyyyMMdd}.pdf"
                };

                if (saveFileDialog.ShowDialog() == true)
                {
                    DataView dataView = (DataView)ReportsGrid.ItemsSource;
                    DataTable table = dataView.Table;

                    using (var writer = new PdfWriter(saveFileDialog.FileName))
                    using (var pdf = new PdfDocument(writer))
                    {
                        PdfFont font;
                        try
                        {
                            font = PdfFontFactory.CreateFont(fontPath, PdfEncodings.IDENTITY_H, PdfFontFactory.EmbeddingStrategy.PREFER_EMBEDDED);
                        }
                        catch
                        {
                            font = PdfFontFactory.CreateFont("Helvetica", PdfEncodings.IDENTITY_H);
                        }

                        var document = new Document(pdf, PageSize.A4.Rotate());
                        document.SetMargins(20, 20, 20, 20);

                        iText.Layout.Style russianStyle = new iText.Layout.Style()
                            .SetFont(font)
                            .SetFontSize(12);

                        document.Add(new iText.Layout.Element.Paragraph("Отчет")
                            .SetTextAlignment(iText.Layout.Properties.TextAlignment.CENTER)
                            .SetFontSize(16)
                            .AddStyle(russianStyle));

                        document.Add(new iText.Layout.Element.Paragraph($"Дата формирования: {DateTime.Now:dd.MM.yyyy HH:mm}")
                            .SetTextAlignment(iText.Layout.Properties.TextAlignment.RIGHT)
                            .SetFontSize(10)
                            .AddStyle(russianStyle));

                        var pdfTable = new iText.Layout.Element.Table(table.Columns.Count)
                            .UseAllAvailableWidth();

                        iText.Layout.Style headerStyle = new iText.Layout.Style()
                            .SetBackgroundColor(new DeviceRgb(51, 102, 153))
                            .SetFontColor(ColorConstants.WHITE)
                            .SetTextAlignment(iText.Layout.Properties.TextAlignment.CENTER)
                            .SetFont(font);

                        foreach (DataColumn column in table.Columns)
                        {
                            pdfTable.AddHeaderCell(new Cell()
                                .Add(new iText.Layout.Element.Paragraph(column.ColumnName)
                                .AddStyle(headerStyle)));
                        }

                        iText.Layout.Style cellStyle = new iText.Layout.Style()
                            .SetFont(font)
                            .SetTextAlignment(iText.Layout.Properties.TextAlignment.CENTER);

                        foreach (DataRow row in table.Rows)
                        {
                            foreach (DataColumn column in table.Columns)
                            {
                                pdfTable.AddCell(new Cell()
                                    .Add(new iText.Layout.Element.Paragraph(row[column].ToString())
                                    .AddStyle(cellStyle)));
                            }
                        }

                        document.Add(pdfTable);

                        document.Add(new iText.Layout.Element.Paragraph("Сгенерировано системой управления альпинистским клубом")
                            .SetTextAlignment(iText.Layout.Properties.TextAlignment.CENTER)
                            .SetFontSize(10)
                            .AddStyle(russianStyle));
                    }

                    MessageBox.Show("Отчет успешно экспортирован в PDF", "Успех",
                                  MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при экспорте в PDF: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (sender is TabControl tabControl)
            {
                if (tabControl.SelectedIndex == 2) 
                {
                    ButtonsPanel.Visibility = Visibility.Collapsed;
                }
                else
                {
                    ButtonsPanel.Visibility = Visibility.Visible;
                }
            }
        }
        private void Close_Click(object sender, RoutedEventArgs e)
            {
                new MounCMain().Show();
                this.Close();
            }
        }
}