﻿using Microsoft.EntityFrameworkCore;
using MountaineeringClub.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace MountaineeringClub.View
{
    public partial class ExpeditionsWindow : Window
    {
        private List<Ascent> _allAscents;

        public ExpeditionsWindow()
        {
            InitializeComponent();
            LoadAscents();
        }

        private void LoadAscents()
        {
            try
            {
                var db = new DbMountaineeringClubContext();
                db.Ascents
                    .Include(a => a.Mountain)
                    .Include(a => a.Applications)
                    .Include(a => a.Photographs)
                    .Load();

                _allAscents = db.Ascents.Local.ToList();
                ExpeditionsDataGrid.ItemsSource = _allAscents.Select(a => new
                {
                    a.AscentId,
                    PhotoBytes = a.Photographs.FirstOrDefault()?.Image,
                    MountainName = a.Mountain?.Name,
                    TargetPoint = a.TargetPoint,
                    a.StartDate,
                    a.EndDate,
                    ParticipantsCount = a.Applications.Count,
                    AscentStatus = a.AscentStatus
                }).ToList();

                UpdateStatusText(_allAscents.Count);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке восхождений: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void UpdateStatusText(int count)
        {
            StatusText.Text = $"Загружено восхождений: {count}";
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            new MounCMain().Show();
            this.Close();
        }

        private void ApplyFiltersButton_Click(object sender, RoutedEventArgs e)
        {
            var filteredAscents = _allAscents.AsEnumerable();

            if (DateFromPicker.SelectedDate.HasValue)
            {
                filteredAscents = filteredAscents.Where(a =>
                    a.StartDate >= DateOnly.FromDateTime(DateFromPicker.SelectedDate.Value));
            }

            if (DateToPicker.SelectedDate.HasValue)
            {
                filteredAscents = filteredAscents.Where(a =>
                    a.EndDate <= DateOnly.FromDateTime(DateToPicker.SelectedDate.Value));
            }

            if (StatusFilterComboBox.SelectedItem is ComboBoxItem selectedStatus &&
                !string.IsNullOrEmpty(selectedStatus.Tag?.ToString()))
            {
                filteredAscents = filteredAscents.Where(a =>
                    a.AscentStatus == selectedStatus.Content.ToString());
            }

            ExpeditionsDataGrid.ItemsSource = filteredAscents.Select(a => new
            {
                a.AscentId,
                PhotoBytes = a.Photographs.FirstOrDefault()?.Image,
                MountainName = a.Mountain?.Name,
                TargetPoint = a.TargetPoint,
                a.StartDate,
                a.EndDate,
                ParticipantsCount = a.Applications.Count,
                AscentStatus = a.AscentStatus
            }).ToList();

            UpdateStatusText(filteredAscents.Count());
        }

        private void ResetFiltersButton_Click(object sender, RoutedEventArgs e)
        {
            DateFromPicker.SelectedDate = null;
            DateToPicker.SelectedDate = null;
            StatusFilterComboBox.SelectedIndex = -1;
            LoadAscents();
        }
    }
}