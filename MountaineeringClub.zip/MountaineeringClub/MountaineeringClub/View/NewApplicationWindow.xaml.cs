﻿using Microsoft.EntityFrameworkCore;
using MountaineeringClub.Model;
using System;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;

namespace MountaineeringClub.View
{
    public partial class NewApplicationWindow : Window
    {
        private User current_user;
        private DbMountaineeringClubContext db;

        public NewApplicationWindow(User user)
        {
            InitializeComponent();
            current_user = user;
            db = new DbMountaineeringClubContext();
            LoadPlannedAscents();
        }

        private void LoadPlannedAscents()
        {
            var plannedAscents = db.Ascents
                .Include(a => a.Mountain)
                .Where(a => a.AscentStatus == "запланировано")
                .OrderBy(a => a.StartDate)
                .ToList();

            MountainComboBox.ItemsSource = plannedAscents;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }

        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            if (MountainComboBox.SelectedItem == null)
            {
                MessageBox.Show("Выберите восхождение", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var selectedAscent = (Ascent)MountainComboBox.SelectedItem;
            var desiredRole = LeaderRadio.IsChecked == true ? "Руководитель" : "Участник";

            var existingApplication = db.Applications
                .FirstOrDefault(a => a.ParticipantId == current_user.UserId &&
                                   a.AscentId == selectedAscent.AscentId);

            if (existingApplication != null)
            {
                MessageBox.Show("У вас уже есть заявка на это восхождение",
                              "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var current_participant = db.Participants
                    .Where(p => p.UserId == current_user.UserId).FirstOrDefault();

            var overlappingApplications = db.Applications
                .Include(a => a.Ascent)
                .Where(a => a.ParticipantId == current_participant.ParticipantId &&
                           a.ApplicationStatus != "отклонено" &&
                           ((selectedAscent.StartDate <= a.Ascent.EndDate &&
                             selectedAscent.EndDate >= a.Ascent.StartDate)))
                .ToList();

            if (overlappingApplications.Any())
            {
                var message = new StringBuilder()
                    .AppendLine("У вас уже есть заявки на следующие пересекающиеся восхождения:")
                    .AppendLine();

                foreach (var app in overlappingApplications)
                {
                    message.AppendLine($"- {app.Ascent.Mountain.Name} ({app.Ascent.StartDate:dd.MM.yyyy} - {app.Ascent.EndDate:dd.MM.yyyy})");
                }

                message.AppendLine();
                message.AppendLine("Вы не можете подать заявку на пересекающиеся по датам восхождения.");

                MessageBox.Show(message.ToString(),
                              "Конфликт дат", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            
                var newApplication = new Model.Application
                {
                    ParticipantId = current_participant.ParticipantId,
                    ApplicationDate = DateOnly.FromDateTime(DateTime.Today),
                    DesiredRole = desiredRole,
                    ApplicationStatus = "на рассмотрении",
                    AscentId = selectedAscent.AscentId
                };

                db.Applications.Add(newApplication);
                db.SaveChanges();

                MessageBox.Show("Заявка успешно подана!", "Успех",
                              MessageBoxButton.OK, MessageBoxImage.Information);
                this.DialogResult = true;
                this.Close();
                
        }

        private void MountainComboBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (MountainComboBox.SelectedItem is Ascent selectedAscent)
            {
                AscentDatesText.Text = $"{selectedAscent.StartDate:dd.MM.yyyy} - {selectedAscent.EndDate:dd.MM.yyyy}";
                RouteDescriptionText.Text = selectedAscent.RouteDescription;
            }
        }
    }
}