﻿using Microsoft.EntityFrameworkCore;
using MountaineeringClub.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace MountaineeringClub.View
{
    public partial class MountainsWindow : Window
    {
        private List<Mountain> _allMountains;

        public MountainsWindow()
        {
            InitializeComponent();
            LoadMountains();

            DataContext = this;
        }

        private void LoadMountains()
        {
            try
            {
                var db = new DbMountaineeringClubContext();
                db.Mountains
                    .Include(m => m.Ascents)
                    .Load();

                _allMountains = db.Mountains.Local.ToList();
                MountainsDataGrid.ItemsSource = _allMountains;
                UpdateStatusText(_allMountains.Count);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке гор: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void UpdateStatusText(int count)
        {
            StatusText.Text = $"Загружено гор: {count}";
        }

        private void ApplyFilters()
        {
            var filteredMountains = _allMountains.AsEnumerable();

            if (!string.IsNullOrWhiteSpace(NameFilterTextBox.Text))
            {
                filteredMountains = filteredMountains.Where(m =>
                    m.Name.Contains(NameFilterTextBox.Text, StringComparison.OrdinalIgnoreCase));
            }

            if (!string.IsNullOrWhiteSpace(CountryFilterTextBox.Text))
            {
                filteredMountains = filteredMountains.Where(m =>
                    m.Country != null && m.Country.Contains(CountryFilterTextBox.Text, StringComparison.OrdinalIgnoreCase));
            }

            if (decimal.TryParse(MinHeightTextBox.Text, out decimal minHeight))
            {
                filteredMountains = filteredMountains.Where(m => m.Height >= minHeight);
            }

            if (decimal.TryParse(MaxHeightTextBox.Text, out decimal maxHeight))
            {
                filteredMountains = filteredMountains.Where(m => m.Height <= maxHeight);
            }

            MountainsDataGrid.ItemsSource = filteredMountains.ToList();
            UpdateStatusText(filteredMountains.Count());
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            new MounCMain().Show();
            this.Close();
        }

        private void ResetFiltersButton_Click(object sender, RoutedEventArgs e)
        {
            NameFilterTextBox.Text = string.Empty;
            CountryFilterTextBox.Text = string.Empty;
            MinHeightTextBox.Text = string.Empty;
            MaxHeightTextBox.Text = string.Empty;

            MountainsDataGrid.ItemsSource = _allMountains;
            UpdateStatusText(_allMountains.Count);
        }

        private void RussianText_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            foreach (var ch in e.Text)
            {
                if (!(ch >= 'А' && ch <= 'я') && ch != ' ' && ch != '-')
                {
                    e.Handled = true;
                    return;
                }
            }
        }

        private void Number_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            foreach (var ch in e.Text)
            {
                if (!char.IsDigit(ch))
                {
                    e.Handled = true;
                    return;
                }
            }
        }
        private void NameFilterTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            ApplyFilters();
        }

        private void CountryFilterTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            ApplyFilters();
        }

        private void HeightTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            ApplyFilters();
        }
    }
}