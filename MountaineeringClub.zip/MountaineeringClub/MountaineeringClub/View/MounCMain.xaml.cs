﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MountaineeringClub.View
{
    /// <summary>
    /// Логика взаимодействия для MounCMain.xaml
    /// </summary>
    public partial class MounCMain : Window
    {
        public MounCMain()
        {
            InitializeComponent();
            LoadDatas();
        }

        private void LoadDatas()
        {
            if (AscentList != null)
                AscentList.Items.Clear();

            AscentList.Items.Add(new NewsControl());
               
            
        }


        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            new LoginWindow().Show();
            this.Close();
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            new RegisterWindow().Show();
            this.Close();
        }

        private void MountainsButton_Click(object sender, RoutedEventArgs e)
        {
            new MountainsWindow().Show(); this.Close();
        }

        private void ExpeditionsButton_Click(object sender, RoutedEventArgs e)
        {
            new ExpeditionsWindow().Show(); this.Close();
        }
    }
}
